export type BackendKind = "webgpu" | "webgl2" | "unsupported";

export async function detectBackend(): Promise<BackendKind> {
  if ("gpu" in navigator) {
    const gpu = (navigator as Navigator & { gpu?: unknown }).gpu;
    if (gpu) {
      // A real implementation must request an adapter/device and handle failure.
      return "webgpu";
    }
  }

  const canvas = document.createElement("canvas");
  const gl = canvas.getContext("webgl2");
  return gl ? "webgl2" : "unsupported";
}
